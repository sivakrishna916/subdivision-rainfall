import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
# Load the dataset
df = pd.read_csv("C:/Users/LENOVO/Downloads/sub-division_rainfall_act_dep_1901-2015.csv")
# Filter relevant parameter types
actual_data = df[df["Parameter"] == "Actual"]
mean_data = df[df["Parameter"] == "Mean"]
std_data = df[df["Parameter"] == "Standard deviation"]
# Convert YEAR to numeric and handle non-numeric values by coercing to NaN
actual_data.loc[:, "YEAR"] = pd.to_numeric(actual_data["YEAR"], errors='coerce')
# Display filtered data
print("Actual Data ")
print(actual_data.head())
print("Mean Data ")
print(mean_data.head())
print("Standard Deviation Data ")
print(std_data.head())
# Set a sample subdivision and year
subdivision = "ANDAMAN & NICOBAR ISLANDS"
year_selected = 2000
months = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC']
#objective 1
# 1. Annual Rainfall Trend for a Subdivision using Seaborn
annual_trend = actual_data[actual_data["SUBDIVISION"] == subdivision].sort_values("YEAR")
# Ensure the columns are numeric and drop rows with NaN values
annual_trend["YEAR"] = pd.to_numeric(annual_trend["YEAR"], errors='coerce')
annual_trend["ANNUAL"] = pd.to_numeric(annual_trend["ANNUAL"], errors='coerce')
# Drop rows with NaN values in either YEAR or ANNUAL columns
annual_trend = annual_trend.dropna(subset=["YEAR", "ANNUAL"])
plt.figure(figsize=(10, 4))
sns.lineplot(data=annual_trend, x="YEAR", y="ANNUAL", label="Annual Rainfall", color='teal')
plt.title(f"Annual Rainfall Trend - {subdivision}")
plt.xlabel("Year")
plt.ylabel("Rainfall (mm)")
plt.grid(True)
plt.tight_layout()
plt.show()
#objective 2
# 2. Monthly Rainfall Distribution for a Specific Year and Subdivision using Seaborn
monthly_data = actual_data[
    (actual_data["SUBDIVISION"] == subdivision) & (actual_data["YEAR"] == year_selected)
]
plt.figure(figsize=(10, 4))
sns.barplot(x=months, y=monthly_data[months].values.flatten(), color='skyblue')
plt.title(f"Monthly Rainfall Distribution - {subdivision} ({year_selected})")
plt.xlabel("Month")
plt.ylabel("Rainfall (mm)")
plt.tight_layout()
plt.show()
#objective 3
# 3. Comparison of Seasonal Rainfall across Subdivisions for a given year
seasonal_data = actual_data[actual_data["YEAR"] == year_selected]
seasonal_data_sorted = seasonal_data.sort_values("JJAS", ascending=False)
plt.figure(figsize=(10, 10))
sns.barplot(x="JJAS", y="SUBDIVISION", data=seasonal_data_sorted, color='lightgreen')
plt.title(f"Monsoon Season Rainfall (JJAS) - All Subdivisions ({year_selected})")
plt.xlabel("Rainfall (mm)")
plt.tight_layout()
plt.show()
#objective 4
# Scatter Plot: Annual Rainfall over Years using Numpy for Linear Fit
plt.figure(figsize=(10, 4))
sns.scatterplot(data=annual_trend, x="YEAR", y="ANNUAL", color='orange', alpha=0.6)
# Perform the linear fit (polyfit)
z = np.polyfit(annual_trend["YEAR"], annual_trend["ANNUAL"], 1)
p = np.poly1d(z)
# Add the trend line to the scatter plot
plt.plot(annual_trend["YEAR"], p(annual_trend["YEAR"]), color='red', linestyle='--', label='Trend Line')
plt.title(f"Annual Rainfall Scatter Plot with Trend - {subdivision}")
plt.xlabel("Year")
plt.ylabel("Rainfall (mm)")
plt.grid(True)
plt.tight_layout()
plt.show()
#objective 5
# Box Plot: Monthly Rainfall Distribution (Updated to fix warning) using Seaborn
monthly_values = actual_data[actual_data["SUBDIVISION"] == subdivision][months]
plt.figure(figsize=(12, 5))
sns.boxplot(data=[monthly_values[month].dropna() for month in months], fliersize=6)
plt.xticks(ticks=range(len(months)), labels=months)
plt.title(f"Monthly Rainfall Box Plot - {subdivision}")
plt.xlabel("Month")
plt.ylabel("Rainfall (mm)")
plt.grid(True)
plt.tight_layout()
plt.show()
